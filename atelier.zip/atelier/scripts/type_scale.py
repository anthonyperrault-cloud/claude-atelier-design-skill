#!/usr/bin/env python3
"""
type_scale.py  —  Typography mathematics engine
================================================
Generates a complete, accessible type scale from ONE decision: the base body
font size. For every step it computes the values that designers (and the rules
in this skill's `library/typography`) say must scale WITH the font size but that
people routinely get wrong:

  * line-height   (leading)        — tightens as size grows, loosens for small text
  * paragraph spacing              — space *between* paragraphs (never double <br>)
  * letter-spacing (tracking)      — tighter on display, looser on captions
  * optimal line length (measure)  — characters per line for comfortable reading

It outputs a plain table (default), ready-to-paste CSS custom properties, or
machine-readable JSON. No external libraries. You give a number; it gives you
a correct, internally-consistent scale.

USAGE
-----
  python3 type_scale.py                         # 16px base, major-third (1.25)
  python3 type_scale.py --base 18 --ratio 1.333 # perfect-fourth scale, 18px body
  python3 type_scale.py --format css            # paste-ready :root variables
  python3 type_scale.py --format json           # machine-readable

RATIOS (common modular-scale ratios)
  1.2   minor third      (subtle, dense UI)
  1.25  major third      (DEFAULT — balanced)
  1.333 perfect fourth   (dramatic, editorial)
  1.414 augmented fourth (very dramatic)
  1.5   perfect fifth    (poster / hero)
  1.618 golden ratio     (expressive)
"""
import argparse
import json
import sys

# Step names from smallest to largest, centred on the base ("base").
STEP_NAMES_DOWN = ["xs", "sm"]          # below base (index order: nearest-to-base last)
STEP_NAMES_UP = ["lg", "xl", "2xl", "3xl", "4xl", "5xl", "6xl", "7xl"]


def round_half_up(value, ndigits=0):
    """Deterministic rounding (Python's banker's rounding surprises non-devs)."""
    factor = 10 ** ndigits
    return int(value * factor + (0.5 if value >= 0 else -0.5)) / factor


def line_height_ratio(font_px):
    """
    Leading model: line-height ratio decreases smoothly as font size increases.
    Calibrated so 16px -> 1.5 and 48px -> ~1.15, clamped to the readable band
    1.1 .. 1.6 (Practical Typography: body 120-145%, display tighter).
        ratio = 0.975 + 8.4 / font_px
    """
    ratio = 0.975 + (8.4 / float(font_px))
    return round_half_up(max(1.10, min(1.60, ratio)), 2)


def tracking_em(font_px):
    """Letter-spacing in em. Big text -> tighter, small text -> looser."""
    if font_px >= 40:
        return -0.03
    if font_px >= 28:
        return -0.02
    if font_px >= 22:
        return -0.01
    if font_px >= 14:
        return 0.0
    return 0.02  # captions / micro


def measure_ch(font_px):
    """Recommended line length (characters). Body 60-75ch; tighten for big display."""
    if font_px >= 40:
        return "20-30ch (display: keep short)"
    if font_px >= 24:
        return "30-50ch (subhead)"
    return "60-75ch (body: ideal 66)"


def build_scale(base_px, ratio, steps_up, steps_down):
    """Return a list of step dicts from smallest to largest."""
    steps = []

    # steps below base
    for i in range(steps_down, 0, -1):
        size = base_px / (ratio ** i)
        name = STEP_NAMES_DOWN[-i] if i <= len(STEP_NAMES_DOWN) else f"down{i}"
        steps.append(_step(name, size, base_px))

    # base
    steps.append(_step("base", float(base_px), base_px, is_base=True))

    # steps above base
    for i in range(1, steps_up + 1):
        size = base_px * (ratio ** i)
        name = STEP_NAMES_UP[i - 1] if i <= len(STEP_NAMES_UP) else f"up{i}"
        steps.append(_step(name, size, base_px))

    return steps


def _step(name, size_px, base_px, is_base=False):
    fs = round_half_up(size_px, 1)
    lh = line_height_ratio(fs)
    lh_px = round_half_up(fs * lh, 1)
    tr = tracking_em(fs)
    para_px = round_half_up(fs * 0.75, 1)  # 0.75em between paragraphs (50-100% band)
    return {
        "name": name,
        "font_px": fs,
        "font_rem": round_half_up(fs / base_px, 3),
        "line_height_ratio": lh,
        "line_height_px": lh_px,
        "letter_spacing_em": tr,
        "paragraph_spacing_px": para_px if is_base else None,
        "paragraph_spacing_em": 0.75 if is_base else None,
        "measure": measure_ch(fs),
        "role": "body / long-form" if is_base else _role_for(name),
    }


def _role_for(name):
    roles = {
        "xs": "fine print / legal", "sm": "captions / helper text",
        "lg": "lead paragraph / large UI", "xl": "h4 / card title",
        "2xl": "h3 / section title", "3xl": "h2", "4xl": "h1",
        "5xl": "hero / display", "6xl": "hero display", "7xl": "billboard",
    }
    return roles.get(name, "")


def emit_table(steps, base_px, ratio):
    out = []
    out.append(f"TYPE SCALE  —  base {base_px}px  ·  ratio {ratio}  ·  {len(steps)} steps")
    out.append("=" * 92)
    hdr = f"{'step':<6}{'px':>7}{'rem':>8}  {'line-height':>22}  {'tracking':>10}  role"
    out.append(hdr)
    out.append("-" * 92)
    for s in steps:
        lh = f"{s['line_height_ratio']} ({s['line_height_px']}px)"
        tr = f"{s['letter_spacing_em']:+.2f}em" if s['letter_spacing_em'] else "0"
        marker = "  <- BODY" if s["name"] == "base" else ""
        out.append(
            f"{s['name']:<6}{s['font_px']:>7}{s['font_rem']:>8}  {lh:>22}  {tr:>10}  {s['role']}{marker}"
        )
    out.append("-" * 92)
    base = next(s for s in steps if s["name"] == "base")
    out.append(f"Paragraph spacing (body): {base['paragraph_spacing_px']}px "
               f"({base['paragraph_spacing_em']}em)  ·  use margin-bottom, never double <br>")
    out.append(f"Line length (measure):    {base['measure']}  ·  set max-width on text containers")
    out.append("Rule of thumb: bold OR italic (never both) · max 2 type families · kerning always on.")
    return "\n".join(out)


def emit_css(steps, base_px):
    lines = [":root {", f"  /* Type scale — base {base_px}px. Generated by type_scale.py */"]
    for s in steps:
        var = s["name"].replace("base", "base")
        lines.append(f"  --fs-{var}: {s['font_rem']}rem;            /* {s['font_px']}px */")
        lines.append(f"  --lh-{var}: {s['line_height_ratio']};")
        if s["letter_spacing_em"]:
            lines.append(f"  --tracking-{var}: {s['letter_spacing_em']:+.2f}em;")
    base = next(s for s in steps if s["name"] == "base")
    lines.append(f"  --paragraph-gap: {base['paragraph_spacing_em']}em;   /* {base['paragraph_spacing_px']}px */")
    lines.append("  --measure: 66ch;            /* max line length for body text */")
    lines.append("}")
    lines.append("")
    lines.append("/* Example usage */")
    lines.append("body { font-size: var(--fs-base); line-height: var(--lh-base); }")
    lines.append("p    { max-width: var(--measure); margin-block-end: var(--paragraph-gap); }")
    lines.append("h1   { font-size: var(--fs-4xl); line-height: var(--lh-4xl); letter-spacing: var(--tracking-4xl); }")
    lines.append("h2   { font-size: var(--fs-3xl); line-height: var(--lh-3xl); letter-spacing: var(--tracking-3xl); }")
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Generate an accessible modular type scale (line-height, paragraph "
                    "spacing, tracking, measure) from a base font size.")
    p.add_argument("--base", type=float, default=16, help="base body font size in px (default 16)")
    p.add_argument("--ratio", type=float, default=1.25, help="modular scale ratio (default 1.25 = major third)")
    p.add_argument("--steps-up", type=int, default=5, help="number of steps above base (default 5)")
    p.add_argument("--steps-down", type=int, default=2, help="number of steps below base (default 2)")
    p.add_argument("--format", choices=["table", "css", "json"], default="table",
                   help="output format (default table)")
    args = p.parse_args(argv)

    if args.base < 8 or args.base > 64:
        print("WARNING: base font size outside the sane web range (8-64px).", file=sys.stderr)
    if args.steps_up > len(STEP_NAMES_UP):
        args.steps_up = len(STEP_NAMES_UP)
    if args.steps_down > len(STEP_NAMES_DOWN):
        args.steps_down = len(STEP_NAMES_DOWN)

    steps = build_scale(args.base, args.ratio, args.steps_up, args.steps_down)

    if args.format == "json":
        print(json.dumps({"base_px": args.base, "ratio": args.ratio, "steps": steps}, indent=2))
    elif args.format == "css":
        print(emit_css(steps, args.base))
    else:
        print(emit_table(steps, args.base, args.ratio))
    return 0


if __name__ == "__main__":
    import signal
    try:
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)  # quiet exit on broken pipe (e.g. | head)
    except (AttributeError, ValueError):
        pass  # SIGPIPE not available on this platform (e.g. Windows)
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        import os
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)
        raise SystemExit(1)
