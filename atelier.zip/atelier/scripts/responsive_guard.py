#!/usr/bin/env python3
"""
responsive_guard.py  —  Mobile-first / responsive safety checker
================================================================
A heuristic linter that scans front-end source (CSS, SCSS, HTML, JSX/TSX, Vue)
for patterns that commonly BREAK layouts or become INTRUSIVE on small screens.
It does not parse or run your code — it pattern-matches the well-known failure
modes documented across this skill's `library` (ui-typography responsive rules,
the bencium RESPONSIVE-DESIGN guides, ui-ux-pro-max layout rules, and the
design-auditor responsive category).

It reports findings as `file:line  SEVERITY  message  -> fix`, prints a summary,
and can emit JSON. Severity is advisory: critical / warning / tip.

WHAT IT CATCHES
  CRITICAL  missing <meta name="viewport">                 (page renders at desktop width on phones)
  CRITICAL  zoom disabled (user-scalable=no / maximum-scale=1)   (accessibility + zoom block)
  WARNING   fixed pixel width > 480px on a container          (horizontal overflow on phones)
  WARNING   min-width above mobile viewport (> 320px)         (clips on the smallest screens)
  WARNING   100vh without dvh/svh fallback                    (mobile browser chrome hides content)
  WARNING   body/input font-size < 16px                       (iOS Safari auto-zooms on focus)
  WARNING   Tailwind arbitrary fixed width  w-[NNNpx]         (won't reflow)
  TIP       overflow:hidden with no max-width in the block    (may clip content on small screens)
  TIP       <img> with no width control (w-full / max-width)  (overflows its container)
  TIP       large fixed Tailwind width (w-80+) w/o sm:/md:    (consider a responsive variant)

USAGE
-----
  python3 responsive_guard.py path/to/file.css
  python3 responsive_guard.py src/            # walks a directory
  python3 responsive_guard.py src/ --json
"""
import argparse
import json
import os
import re
import sys

EXTS = (".css", ".scss", ".sass", ".html", ".htm", ".jsx", ".tsx", ".js", ".ts", ".vue")

# (compiled_regex, severity, message, fix)
LINE_CHECKS = [
    (re.compile(r"user-scalable\s*=\s*no", re.I), "critical",
     "Zoom disabled via user-scalable=no",
     "Remove it — blocking zoom fails WCAG 1.4.4 and hurts low-vision users."),
    (re.compile(r"maximum-scale\s*=\s*1(\.0+)?\b", re.I), "critical",
     "Zoom capped via maximum-scale=1",
     "Remove maximum-scale — let users pinch-zoom."),
    (re.compile(r"\b(min-width)\s*:\s*(\d{3,})px", re.I), "warning",
     "min-width above the smallest phone width",
     "Keep min-width <= 320px (or unset) so it doesn't clip on small screens."),
    (re.compile(r"\b100vh\b", re.I), "warning",
     "100vh does not account for mobile browser chrome",
     "Use 100dvh (dynamic) or min-height:100svh so content isn't hidden behind the address bar."),
    (re.compile(r"w-\[(\d{3,})px\]"), "warning",
     "Tailwind arbitrary fixed width (won't reflow)",
     "Use a fluid width (w-full, max-w-*) or a responsive variant."),
    (re.compile(r"\bw-(8\d|9\d|\d{3,})\b"), "tip",
     "Large fixed Tailwind width without a responsive prefix nearby",
     "Add sm:/md: overrides or switch to max-w-* so it shrinks on mobile."),
]

# width: NNNpx where NNN > 480 — only flag on layout-ish properties, skip max-width/min-width.
FIXED_WIDTH = re.compile(r"(?<![-a-z])width\s*:\s*(\d{3,})px", re.I)
FONT_SIZE = re.compile(r"font-size\s*:\s*(\d{1,2})px", re.I)
VIEWPORT_META = re.compile(r'name\s*=\s*["\']viewport["\']', re.I)
IMG_TAG = re.compile(r"<img\b[^>]*>", re.I)
IMG_HAS_WIDTH = re.compile(r'(w-full|max-w|width\s*:|className="[^"]*\b(w-|max-w-)|style=)', re.I)


def is_html_like(path):
    return path.lower().endswith((".html", ".htm", ".jsx", ".tsx", ".vue"))


def scan_text(path, text):
    findings = []
    lines = text.splitlines()

    # Per-line regex checks
    for ln, line in enumerate(lines, 1):
        for rx, sev, msg, fix in LINE_CHECKS:
            if rx.search(line):
                findings.append((path, ln, sev, msg, fix))
        m = FIXED_WIDTH.search(line)
        if m and int(m.group(1)) > 480:
            findings.append((path, ln, "warning",
                             f"Fixed width {m.group(1)}px on a container",
                             "Use max-width or % — fixed widths > 480px overflow on phones."))
        mf = FONT_SIZE.search(line)
        if mf and int(mf.group(1)) < 16 and re.search(r"\b(body|input|textarea|select)\b", line, re.I):
            findings.append((path, ln, "warning",
                             f"font-size {mf.group(1)}px on body/input",
                             "Use >= 16px on body & form fields — iOS Safari auto-zooms below that."))
        for im in IMG_TAG.finditer(line):
            tag = im.group(0)
            if not IMG_HAS_WIDTH.search(tag):
                findings.append((path, ln, "tip",
                                 "<img> has no width control",
                                 "Add max-width:100% (or w-full) so it never overflows its container."))

    # Whole-file: viewport meta on HTML pages
    if path.lower().endswith((".html", ".htm")) and "<head" in text.lower():
        if not VIEWPORT_META.search(text):
            findings.append((path, 1, "critical",
                             "Missing <meta name=\"viewport\">",
                             'Add <meta name="viewport" content="width=device-width, initial-scale=1"> '
                             "or mobile browsers render at desktop width."))

    # Block-level: overflow:hidden with no max-width in the same rule block
    if path.lower().endswith((".css", ".scss", ".sass")):
        for block_start, block in iter_css_blocks(text):
            if re.search(r"overflow\s*:\s*hidden", block, re.I) and not re.search(r"max-width", block, re.I):
                findings.append((path, block_start, "tip",
                                 "overflow:hidden in a block with no max-width",
                                 "Confirm content can't be clipped on small screens; add max-width if it's a text container."))
    return findings


def iter_css_blocks(text):
    """Yield (line_number_of_block_open, block_body) for each {...} block. Naive but safe."""
    line_of = []
    n = 1
    for ch in text:
        line_of.append(n)
        if ch == "\n":
            n += 1
    blocks = []
    depth = 0
    start = None
    body = []
    for i, ch in enumerate(text):
        if ch == "{":
            if depth == 0:
                start = line_of[i]
                body = []
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start is not None:
                blocks.append((start, "".join(body)))
                start = None
        elif depth > 0:
            body.append(ch)
    return blocks


def collect_files(target):
    if os.path.isfile(target):
        return [target]
    files = []
    for root, _dirs, names in os.walk(target):
        if "node_modules" in root or "/.git" in root:
            continue
        for name in names:
            if name.lower().endswith(EXTS):
                files.append(os.path.join(root, name))
    return files


SEV_ORDER = {"critical": 0, "warning": 1, "tip": 2}
SEV_TAG = {"critical": "CRITICAL", "warning": "WARNING ", "tip": "TIP     "}


def main(argv=None):
    p = argparse.ArgumentParser(description="Scan front-end source for mobile/responsive safety issues.")
    p.add_argument("target", help="file or directory to scan")
    p.add_argument("--json", action="store_true", help="emit machine-readable JSON")
    args = p.parse_args(argv)

    if not os.path.exists(args.target):
        print(f"ERROR: path not found: {args.target}", file=sys.stderr)
        return 2

    files = collect_files(args.target)
    all_findings = []
    for f in files:
        try:
            with open(f, "r", encoding="utf-8", errors="replace") as fh:
                all_findings.extend(scan_text(f, fh.read()))
        except OSError:
            continue

    all_findings.sort(key=lambda x: (SEV_ORDER[x[2]], x[0], x[1]))
    counts = {"critical": 0, "warning": 0, "tip": 0}
    for _f, _ln, sev, _m, _fix in all_findings:
        counts[sev] += 1

    if args.json:
        print(json.dumps({
            "files_scanned": len(files),
            "summary": counts,
            "findings": [
                {"file": f, "line": ln, "severity": sev, "message": m, "fix": fix}
                for (f, ln, sev, m, fix) in all_findings
            ],
        }, indent=2))
        return 1 if counts["critical"] else 0

    print(f"RESPONSIVE GUARD  —  scanned {len(files)} file(s)")
    print("=" * 78)
    if not all_findings:
        print("No responsive-safety issues found. (Heuristic scan — eyes still matter.)")
    for f, ln, sev, msg, fix in all_findings:
        print(f"{f}:{ln}  {SEV_TAG[sev]}  {msg}")
        print(f"        -> {fix}")
    print("-" * 78)
    print(f"Summary: {counts['critical']} critical · {counts['warning']} warning · {counts['tip']} tip")
    print("Heuristic check — it flags likely problems, it does not prove correctness.")
    return 1 if counts["critical"] else 0


if __name__ == "__main__":
    import signal
    try:
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)  # quiet exit on broken pipe (e.g. | head)
    except (AttributeError, ValueError):
        pass  # SIGPIPE not available on this platform (e.g. Windows)
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        import os
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)
        raise SystemExit(1)
