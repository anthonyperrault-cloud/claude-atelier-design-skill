#!/usr/bin/env python3
"""
rad_spacing.py  —  Hierarchical spacing calculator (the "rad spacing" 40% rule)
===============================================================================
Implements the spacing method from `library/layout-spacing/rad-spacing`: spacing
communicates hierarchy via the Gestalt principle of proximity. Outer containers
get proportionally MORE space than inner elements, so the eye parses groupings
without needing dividers.

THE RULE (faithful to the rad-spacing skill)
  * Each parent level ≈ 1.4× the spacing of its child level (~40% step).
  * Snap each result to the nearest 8px increment. If the raw value lands closer
    to a 4px increment than to an 8px increment, use the 4px value instead.
  * Work from the innermost element outward (base = tightest grouping, default 8px).
  * Cap the outermost level (default 64px) and floor the innermost (4px).

It also emits the rad-spacing default semantic token scale
(xs 4 · sm 8 · md 12 · lg 16 · xl 24 · 2xl 32 · 3xl 48) so you can drop it
straight into Figma variables or a Tailwind/CSS theme.

USAGE
-----
  python3 rad_spacing.py                          # 5 levels, base 8px, 1.4x
  python3 rad_spacing.py --base 8 --levels 6      # 6 hierarchy levels
  python3 rad_spacing.py --format css             # spacing tokens as CSS vars
  python3 rad_spacing.py --format json
"""
import argparse
import json

# Default semantic scale named in the rad-spacing skill.
SEMANTIC_SCALE = [
    ("xs", 4), ("sm", 8), ("md", 12), ("lg", 16),
    ("xl", 24), ("2xl", 32), ("3xl", 48),
]

LEVEL_ROLES = [
    "innermost (label <-> input, inline elements)",
    "fields within a group",
    "groups / form sections",
    "section padding",
    "content-area padding",
    "page padding",
    "outermost shell",
]


def snap(value):
    """
    Snap to nearest 8px; if the nearest 4px increment is strictly closer to the
    raw value than the nearest 8px increment, prefer the 4px value (per the rule).
    Ties go to the 8px grid.
    """
    near8 = round(value / 8.0) * 8
    near4 = round(value / 4.0) * 4
    d8 = abs(value - near8)
    d4 = abs(value - near4)
    chosen = near4 if d4 < d8 else near8
    return int(chosen)


def build_levels(base, levels, ratio, max_cap, floor_px):
    """
    Returns levels from innermost (index 0) to outermost. Each step multiplies
    the previous raw value by `ratio`, then snaps, applying floor and cap.
    """
    rows = []
    raw = float(base)
    for i in range(levels):
        value = snap(raw)
        if value < floor_px:
            value = floor_px
        if value > max_cap:
            value = max_cap
        role = LEVEL_ROLES[i] if i < len(LEVEL_ROLES) else f"level {i}"
        calc = "base value" if i == 0 else f"{rows[-1]['raw']:.1f} x {ratio} = {raw:.1f} -> snap {value}"
        rows.append({
            "level": i,
            "depth_label": f"L{i} ({'innermost' if i == 0 else 'outermost' if i == levels - 1 else 'mid'})",
            "role": role,
            "raw": raw,
            "value_px": value,
            "calculation": calc,
        })
        raw = raw * ratio
    # Reverse for display so outermost prints first (page -> inner), but keep data inner->out.
    return rows


def emit_table(rows, base, ratio, cap, floor_px):
    out = []
    out.append(f"HIERARCHICAL SPACING  —  base {base}px · step {ratio}x (~40%) · "
               f"snap 8/4px · floor {floor_px} · cap {cap}")
    out.append("=" * 86)
    out.append(f"{'level':<7}{'value':>8}   role / where it applies")
    out.append("-" * 86)
    for r in reversed(rows):  # outermost first reads like a page from outside in
        tag = "PADDING" if "padding" in r["role"] or "shell" in r["role"] else "GAP"
        out.append(f"{r['depth_label']:<7}{str(r['value_px']) + 'px':>8}   [{tag}] {r['role']}")
    out.append("-" * 86)
    out.append("Apply: padding on container frames; gap (itemSpacing) between siblings.")
    out.append("Validate: outer groups feel separated; inner items feel cohesive; every")
    out.append("adjacent pair is visibly different — if two levels look the same, the step is too small.")
    out.append("")
    out.append("Calculation trace (innermost -> outermost):")
    for r in rows:
        out.append(f"  {r['depth_label']}: {r['calculation']}")
    out.append("")
    out.append("rad-spacing default semantic scale (create these as variables if none exist):")
    out.append("  " + "  ".join(f"{n}={v}" for n, v in SEMANTIC_SCALE))
    return "\n".join(out)


def emit_css(rows):
    lines = [":root {", "  /* rad-spacing semantic scale */"]
    for n, v in SEMANTIC_SCALE:
        lines.append(f"  --space-{n}: {v}px;")
    lines.append("")
    lines.append("  /* Hierarchical assignment for this layout (innermost -> outermost) */")
    for r in rows:
        lines.append(f"  --space-l{r['level']}: {r['value_px']}px;  /* {r['role']} */")
    lines.append("}")
    return "\n".join(lines)


def main(argv=None):
    p = argparse.ArgumentParser(
        description="Compute hierarchical spacing using the rad-spacing 40% rule "
                    "with 8/4px snapping, plus the default semantic spacing scale.")
    p.add_argument("--base", type=float, default=8, help="tightest (innermost) spacing in px (default 8)")
    p.add_argument("--levels", type=int, default=5, help="number of hierarchy levels (default 5)")
    p.add_argument("--ratio", type=float, default=1.4, help="step multiplier per level (default 1.4 = ~40%%)")
    p.add_argument("--max-cap", type=int, default=64, help="cap for the outermost level (default 64)")
    p.add_argument("--min", type=int, default=4, dest="floor_px", help="floor for the innermost level (default 4)")
    p.add_argument("--format", choices=["table", "css", "json"], default="table")
    args = p.parse_args(argv)

    if args.levels < 1:
        args.levels = 1
    rows = build_levels(args.base, args.levels, args.ratio, args.max_cap, args.floor_px)

    if args.format == "json":
        print(json.dumps({
            "base": args.base, "ratio": args.ratio, "cap": args.max_cap,
            "floor": args.floor_px, "levels": rows, "semantic_scale": dict(SEMANTIC_SCALE),
        }, indent=2))
    elif args.format == "css":
        print(emit_css(rows))
    else:
        print(emit_table(rows, args.base, args.ratio, args.max_cap, args.floor_px))
    return 0


if __name__ == "__main__":
    import signal
    try:
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)  # quiet exit on broken pipe (e.g. | head)
    except (AttributeError, ValueError):
        pass  # SIGPIPE not available on this platform (e.g. Windows)
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        import os
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)
        raise SystemExit(1)
