#!/usr/bin/env python3
"""
slop_check.py  —  Anti-slop prose linter
========================================
Scans prose (Markdown, plain text, or piped stdin) for the predictable AI
writing tells catalogued in this skill's `library/copywriting/stop-slop`:
throat-clearing openers, emphasis crutches, business jargon, empty adverbs,
meta-commentary, binary-contrast scaffolding, false agency, narrator-from-a-
distance, and em dashes.

For every hit it reports `line:col  [category]  "matched text"  -> action`,
tallies hits per category, and prints a rough 1-10 readability pressure score
per the stop-slop rubric. This checks PROSE you wrote — point it at copy,
articles, or docs, not at code.

USAGE
-----
  python3 slop_check.py draft.md
  echo "Here's the thing: we should just ship it." | python3 slop_check.py -
  python3 slop_check.py draft.md --json
"""
import argparse
import json
import re
import sys

# Each entry: (regex, category, action). Word-boundaried, case-insensitive.
def w(p):  # whole-phrase, case-insensitive, word-ish boundaries
    return re.compile(r"(?<![\w'])(" + p + r")(?![\w'])", re.I)


CHECKS = []

# --- Throat-clearing openers ---
for phrase in [
    r"here'?s the thing", r"here'?s what", r"here'?s why", r"here'?s how",
    r"the uncomfortable truth is", r"it turns out", r"let me be clear",
    r"the truth is", r"i'?m going to be honest", r"can we talk about",
    r"the real \w+ is",
]:
    CHECKS.append((w(phrase), "throat-clearing", "Cut the preamble; state the point directly."))

# --- Emphasis crutches ---
for phrase in [r"full stop", r"let that sink in", r"make no mistake",
               r"here'?s why that matters", r"this matters because"]:
    CHECKS.append((w(phrase), "emphasis-crutch", "Delete — it adds no meaning."))

# --- Business jargon -> plain word ---
JARGON = {
    "navigate": "handle / address", "unpack": "explain / examine",
    "lean into": "accept / embrace", "landscape": "situation / field",
    "game-?changer": "significant", "double down": "commit",
    "deep dive": "analysis", "moving forward": "next",
    "circle back": "return to", "take a step back": "reconsider",
    "on the same page": "aligned",
}
for jarg, repl in JARGON.items():
    CHECKS.append((w(jarg), "jargon", f"Replace with plain language: {repl}."))

# --- Adverbs / empty intensifiers ---
for adv in ["really", "just", "literally", "genuinely", "honestly", "simply",
            "actually", "deeply", "truly", "fundamentally", "inherently",
            "inevitably", "interestingly", "importantly", "crucially"]:
    CHECKS.append((w(adv), "adverb", "Kill the adverb; let the verb/noun carry it."))

# --- Filler phrases ---
for phrase in [r"at its core", r"in today'?s \w+", r"it'?s worth noting",
               r"at the end of the day", r"when it comes to", r"in a world where",
               r"the reality is"]:
    CHECKS.append((w(phrase), "filler", "Cut the filler phrase."))

# --- Meta-commentary ---
for phrase in [r"plot twist", r"spoiler", r"you already know this,? but",
               r"let me walk you through", r"in this section,? we'?ll",
               r"as we'?ll see", r"the rest of this (essay|post|article)",
               r"i want to explore"]:
    CHECKS.append((w(phrase), "meta-commentary", "Delete — let the writing move, don't narrate it."))

# --- Lazy extremes ---
for phrase in ["everyone", "everybody", "nobody", "always", "never", "every single"]:
    CHECKS.append((w(phrase), "lazy-extreme", "Replace sweeping claim with a specific."))

# --- Rhetorical setups / permission ---
for phrase in [r"think about it", r"here'?s what i mean", r"and that'?s okay"]:
    CHECKS.append((w(phrase), "rhetorical-setup", "Make the point; let readers conclude."))

# Patterns that need regex (contrasts, fragments, false agency) — search anywhere on line.
PATTERN_CHECKS = [
    (re.compile(r"\bnot because\b.*?\b(but )?because\b", re.I), "binary-contrast",
     "Drop the negation — state the real reason directly."),
    (re.compile(r"\bisn'?t\b[^.,;]{1,40}\bit'?s\b", re.I), "binary-contrast",
     'Telegraphed reframe ("isn\'t X, it\'s Y") — state Y directly.'),
    (re.compile(r"\bnot just\b[^.,;]{1,40}\bbut (also )?\b", re.I), "binary-contrast",
     'Additive hedge ("not just X but also Y") — say both plainly.'),
    (re.compile(r"\bthe (question|answer|problem) isn'?t\b", re.I), "binary-contrast",
     "Rhetorical misdirection — lead with the real subject."),
    (re.compile(r"\bthat'?s it\.\s*that'?s the\b", re.I), "dramatic-fragment",
     "Performative simplicity — use one complete sentence."),
    (re.compile(r"\bwhat if\b.*\?", re.I), "rhetorical-setup",
     "Socratic posturing — assert the idea instead of asking."),
    (re.compile(r"\b(the data|the market|the culture|the decision|the conversation|the complaint)\s+"
                r"(tells|rewards|shifts|emerges|moves|becomes)\b", re.I), "false-agency",
     "Inanimate thing doing a human verb — name the person who acts."),
    (re.compile(r"\b(this happens because|this is why|people tend to|nobody designed)\b", re.I),
     "narrator-distance", "Put the reader in the scene; drop the lecturer voice."),
    (re.compile(r"\bthe (reasons|implications|stakes|consequences) (are|is)\b", re.I),
     "vague-declarative", "Name the specific thing instead of announcing importance."),
    (re.compile(r"\u2014"), "em-dash", "Remove the em dash — use a comma or period."),
    (re.compile(r"!{2,}"), "exclamation-spam", "One exclamation point maximum; never stack them."),
]

CATEGORY_WEIGHTS = {  # rough deduction for the pressure score
    "throat-clearing": 3, "binary-contrast": 3, "false-agency": 3, "vague-declarative": 3,
    "jargon": 2, "meta-commentary": 2, "narrator-distance": 2, "em-dash": 2,
    "emphasis-crutch": 2, "rhetorical-setup": 2, "dramatic-fragment": 2,
    "adverb": 1, "filler": 1, "lazy-extreme": 1, "exclamation-spam": 1,
}


def scan(text):
    findings = []
    for ln, line in enumerate(text.splitlines(), 1):
        for rx, cat, action in CHECKS:
            for m in rx.finditer(line):
                findings.append((ln, m.start() + 1, cat, m.group(0), action))
        for rx, cat, action in PATTERN_CHECKS:
            for m in rx.finditer(line):
                snippet = m.group(0).strip()
                if len(snippet) > 48:
                    snippet = snippet[:45] + "..."
                findings.append((ln, m.start() + 1, cat, snippet, action))
    findings.sort(key=lambda x: (x[0], x[1]))
    return findings


def main(argv=None):
    p = argparse.ArgumentParser(description="Flag AI 'slop' patterns in prose (stop-slop rules).")
    p.add_argument("path", help="text/markdown file, or - for stdin")
    p.add_argument("--json", action="store_true", help="machine-readable output")
    args = p.parse_args(argv)

    if args.path == "-":
        text = sys.stdin.read()
        label = "<stdin>"
    else:
        try:
            with open(args.path, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except OSError as e:
            print(f"ERROR: {e}", file=sys.stderr)
            return 2
        label = args.path

    findings = scan(text)
    counts = {}
    deduction = 0
    for _ln, _col, cat, _txt, _act in findings:
        counts[cat] = counts.get(cat, 0) + 1
        deduction += CATEGORY_WEIGHTS.get(cat, 1)
    score = max(0, 50 - deduction)  # stop-slop rubric: below 35/50 -> revise

    if args.json:
        print(json.dumps({
            "file": label, "score_out_of_50": score, "revise": score < 35,
            "counts": counts,
            "findings": [
                {"line": ln, "col": col, "category": cat, "match": txt, "action": act}
                for (ln, col, cat, txt, act) in findings
            ],
        }, indent=2))
        return 1 if findings else 0

    print(f"SLOP CHECK  —  {label}")
    print("=" * 78)
    if not findings:
        print("No slop patterns detected. Clean prose.")
    for ln, col, cat, txt, act in findings:
        print(f"{ln}:{col}  [{cat}]  \"{txt}\"")
        print(f"        -> {act}")
    print("-" * 78)
    if counts:
        print("By category: " + " · ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    verdict = "REVISE (below 35/50)" if score < 35 else "acceptable"
    print(f"Pressure score: {score}/50  ->  {verdict}")
    print("Score is a rough signal from pattern density, not a measure of meaning.")
    return 1 if findings else 0


if __name__ == "__main__":
    import signal
    try:
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)  # quiet exit on broken pipe (e.g. | head)
    except (AttributeError, ValueError):
        pass  # SIGPIPE not available on this platform (e.g. Windows)
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        import os
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)
        raise SystemExit(1)
