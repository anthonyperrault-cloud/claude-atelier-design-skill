#!/usr/bin/env python3
"""
contrast_check.py  —  WCAG contrast checker + fixer
===================================================
Computes WCAG 2.1 contrast ratios using the exact sRGB relative-luminance
formula. Two modes:

  PAIR MODE   compare a foreground and background colour directly.
              python3 contrast_check.py "#555" "#ffffff"

  SCAN MODE   read a CSS/SCSS file, find every rule block that sets BOTH a text
              colour and a background, and flag the pairs that fail.
              python3 contrast_check.py --scan styles.css

For any failing pair it suggests the NEAREST passing foreground (it nudges the
text colour darker or lighter until it clears the threshold), so you get an
actionable fix, not just a verdict.

THRESHOLDS (WCAG 2.1)
  AA  normal text >= 4.5:1   ·  large text (>=18.66px bold / 24px) >= 3:1  ·  UI/graphics >= 3:1
  AAA normal text >= 7:1     ·  large text >= 4.5:1

Accepts colours as #rgb, #rrggbb, rgb(r,g,b) or rgba(r,g,b,a) (alpha ignored).
No external libraries.
"""
import argparse
import json
import re
import sys

HEX3 = re.compile(r"^#?([0-9a-fA-F]{3})$")
HEX6 = re.compile(r"^#?([0-9a-fA-F]{6})$")
RGB = re.compile(r"rgba?\(\s*(\d{1,3})\s*,\s*(\d{1,3})\s*,\s*(\d{1,3})", re.I)


def parse_color(text):
    """Return (r, g, b) 0-255 or None."""
    if text is None:
        return None
    t = text.strip()
    m = HEX6.match(t)
    if m:
        h = m.group(1)
        return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16))
    m = HEX3.match(t)
    if m:
        h = m.group(1)
        return (int(h[0] * 2, 16), int(h[1] * 2, 16), int(h[2] * 2, 16))
    m = RGB.search(t)
    if m:
        return tuple(min(255, int(m.group(i))) for i in (1, 2, 3))
    return None


def to_hex(rgb):
    return "#%02x%02x%02x" % rgb


def _lin(c):
    c = c / 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def luminance(rgb):
    r, g, b = (_lin(x) for x in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def ratio(fg, bg):
    l1, l2 = luminance(fg), luminance(bg)
    hi, lo = max(l1, l2), min(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def grades(r):
    return {
        "AA_normal": r >= 4.5,
        "AA_large": r >= 3.0,
        "AA_ui": r >= 3.0,
        "AAA_normal": r >= 7.0,
        "AAA_large": r >= 4.5,
    }


def nearest_passing(fg, bg, target=4.5):
    """Nudge fg toward black or white (whichever direction passes) until it clears target."""
    if ratio(fg, bg) >= target:
        return fg, 0
    bg_lum = luminance(bg)
    # If background is light, darken text; if dark, lighten text.
    toward = (0, 0, 0) if bg_lum > 0.5 else (255, 255, 255)
    best = fg
    for step in range(1, 101):
        t = step / 100.0
        cand = tuple(round(fg[i] + (toward[i] - fg[i]) * t) for i in range(3))
        if ratio(cand, bg) >= target:
            return cand, step
        best = cand
    return best, 100


def iter_css_blocks(text):
    n = 1
    line_of = []
    for ch in text:
        line_of.append(n)
        if ch == "\n":
            n += 1
    blocks = []
    depth = 0
    start = None
    body = []
    for i, ch in enumerate(text):
        if ch == "{":
            if depth == 0:
                start = line_of[i]
                body = []
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0 and start is not None:
                blocks.append((start, "".join(body)))
                start = None
        elif depth > 0:
            body.append(ch)
    return blocks


COLOR_PROP = re.compile(r"(?<![-\w])color\s*:\s*([^;]+);", re.I)
BG_PROP = re.compile(r"background(?:-color)?\s*:\s*([^;]+);", re.I)


def report_pair(fg_raw, bg_raw, level="AA", as_json=False):
    fg, bg = parse_color(fg_raw), parse_color(bg_raw)
    if not fg or not bg:
        print(f"ERROR: could not parse colour(s): fg={fg_raw!r} bg={bg_raw!r}", file=sys.stderr)
        return 2
    r = ratio(fg, bg)
    g = grades(r)
    target = 7.0 if level == "AAA" else 4.5
    suggestion = None
    if r < target:
        fixed, _steps = nearest_passing(fg, bg, target)
        suggestion = to_hex(fixed)

    if as_json:
        print(json.dumps({
            "foreground": to_hex(fg), "background": to_hex(bg),
            "ratio": round(r, 2), "grades": g,
            "passes_target": r >= target, "target_level": level,
            "suggested_foreground": suggestion,
        }, indent=2))
        return 0 if r >= target else 1

    print(f"CONTRAST  {to_hex(fg)} on {to_hex(bg)}")
    print("=" * 48)
    print(f"  ratio: {r:.2f}:1")
    print(f"  AA  normal (>=4.5): {'PASS' if g['AA_normal'] else 'FAIL'}")
    print(f"  AA  large  (>=3.0): {'PASS' if g['AA_large'] else 'FAIL'}")
    print(f"  AAA normal (>=7.0): {'PASS' if g['AAA_normal'] else 'FAIL'}")
    print(f"  AAA large  (>=4.5): {'PASS' if g['AAA_large'] else 'FAIL'}")
    if suggestion:
        print(f"  -> nearest passing text colour for {level}: {suggestion} "
              f"({ratio(parse_color(suggestion), bg):.2f}:1)")
    else:
        print(f"  -> passes {level}. No change needed.")
    return 0 if r >= target else 1


def report_scan(path, level="AA", as_json=False):
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fh:
            text = fh.read()
    except OSError as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 2

    target = 7.0 if level == "AAA" else 4.5
    findings = []
    for ln, block in iter_css_blocks(text):
        cm = COLOR_PROP.search(block)
        bm = BG_PROP.search(block)
        if not cm or not bm:
            continue
        fg = parse_color(cm.group(1))
        bg = parse_color(bm.group(1))
        if not fg or not bg:
            continue
        r = ratio(fg, bg)
        if r < target:
            fixed, _ = nearest_passing(fg, bg, target)
            findings.append({
                "line": ln, "foreground": to_hex(fg), "background": to_hex(bg),
                "ratio": round(r, 2), "suggested_foreground": to_hex(fixed),
            })

    if as_json:
        print(json.dumps({"file": path, "target_level": level,
                          "failing_pairs": findings}, indent=2))
        return 1 if findings else 0

    print(f"CONTRAST SCAN  —  {path}  (target {level})")
    print("=" * 64)
    if not findings:
        print("No failing colour pairs found in same-rule color/background blocks.")
    for f in findings:
        print(f"{path}:{f['line']}  FAIL  {f['foreground']} on {f['background']}  "
              f"= {f['ratio']}:1  -> use {f['suggested_foreground']}")
    print("-" * 64)
    print(f"{len(findings)} failing pair(s). Note: only checks colour+background set in the SAME rule.")
    return 1 if findings else 0


def main(argv=None):
    p = argparse.ArgumentParser(description="WCAG contrast checker with nearest-passing-colour suggestions.")
    p.add_argument("fg", nargs="?", help="foreground colour (pair mode)")
    p.add_argument("bg", nargs="?", help="background colour (pair mode)")
    p.add_argument("--scan", metavar="FILE", help="scan a CSS/SCSS file for failing pairs")
    p.add_argument("--level", choices=["AA", "AAA"], default="AA", help="target conformance (default AA)")
    p.add_argument("--json", action="store_true", help="machine-readable output")
    args = p.parse_args(argv)

    if args.scan:
        return report_scan(args.scan, args.level, args.json)
    if args.fg and args.bg:
        return report_pair(args.fg, args.bg, args.level, args.json)
    p.print_help()
    return 2


if __name__ == "__main__":
    import signal
    try:
        signal.signal(signal.SIGPIPE, signal.SIG_DFL)  # quiet exit on broken pipe (e.g. | head)
    except (AttributeError, ValueError):
        pass  # SIGPIPE not available on this platform (e.g. Windows)
    try:
        raise SystemExit(main())
    except BrokenPipeError:
        import os
        os.dup2(os.open(os.devnull, os.O_WRONLY), 1)
        raise SystemExit(1)
