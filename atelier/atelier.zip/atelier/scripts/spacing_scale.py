#!/usr/bin/env python3
"""
atelier — spacing scale generator
=================================
Turns the hierarchical proximity method in references/layout-spacing.md into exact numbers.

The method: each parent level gets about 1.4x the spacing of its child level. Each result is
snapped to the nearest 8px step, or the nearest 4px step when that lands closer. The innermost
level is floored at 4px; the outermost is capped (default 48px) so deep trees stay sane.

Usage:
    python3 spacing_scale.py                      # base 8, 5 levels, default cap
    python3 spacing_scale.py --base 8 --levels 5
    python3 spacing_scale.py --base 8 --levels 6 --ratio 1.4 --cap 64

Note: a base below ~6px will flatline (e.g. 4 x 1.4 = 5.6, which snaps back to 4). Start from 8px,
the documented tightest grouping, unless you have a specific reason not to.

Output is a table from innermost (child) to outermost (page), matching how layout-spacing.md
describes working outward from the tightest grouping.
"""

import argparse


def snap(value: float) -> int:
    """Snap to nearest multiple of 8, unless the nearest multiple of 4 is strictly closer."""
    near8 = round(value / 8) * 8
    near4 = round(value / 4) * 4
    if abs(value - near4) < abs(value - near8):
        return int(near4)
    return int(near8)


def build_scale(base: int, levels: int, ratio: float, cap: int):
    """Return spacing per level, working outward from the base.

    Each level compounds from the PREVIOUS SNAPPED value (not a running raw float), which is how
    references/layout-spacing.md derives its worked example: 8 -> 12 -> 16 -> 24 -> 32.
    """
    scale = []
    prev = max(4, snap(float(base)))  # innermost, floored at 4px
    scale.append(prev)
    for _ in range(1, levels):
        value = min(cap, max(4, snap(prev * ratio)))  # compound from snapped previous, capped
        scale.append(value)
        prev = value
    return scale


LEVEL_NAMES = [
    "inline / tightest grouping",
    "items within a group",
    "groups within a section",
    "section padding",
    "container padding",
    "page padding",
    "outer shell",
]


def main():
    ap = argparse.ArgumentParser(description="Generate an atelier hierarchical spacing scale.")
    ap.add_argument("--base", type=int, default=8, help="tightest spacing in px (default 8)")
    ap.add_argument("--levels", type=int, default=5, help="number of nesting levels (default 5)")
    ap.add_argument("--ratio", type=float, default=1.4, help="parent-to-child ratio (default 1.4)")
    ap.add_argument("--cap", type=int, default=48, help="max spacing for outer levels (default 48)")
    args = ap.parse_args()

    if args.levels < 1:
        print("levels must be at least 1")
        return 1

    scale = build_scale(args.base, args.levels, args.ratio, args.cap)

    print(f"atelier spacing scale  (base {args.base}px, ratio {args.ratio}x, cap {args.cap}px)")
    print(f"  {'level':<6} {'role':<28} {'spacing':>8}")
    print(f"  {'-'*6} {'-'*28} {'-'*8}")
    for i, value in enumerate(scale):
        role = LEVEL_NAMES[i] if i < len(LEVEL_NAMES) else f"level {i}"
        marker = "  (gap)" if i < 2 else "  (padding)"
        print(f"  {i:<6} {role:<28} {str(value)+'px':>8}{marker}")

    css = "  ".join(f"--space-l{i}: {v}px;" for i, v in enumerate(scale))
    print("\n  CSS custom properties:")
    print(f"    {css}")
    print("\n  processed levels:", len(scale), "— complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
