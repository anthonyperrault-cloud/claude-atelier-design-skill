#!/usr/bin/env python3
"""
atelier — integrity validator
==============================
Confirms the skill is structurally sound before you commit it anywhere.

Checks, in order:
  1. SKILL.md exists and has valid YAML-style frontmatter (name + description).
  2. Every `references/...md` path named in SKILL.md's routing map resolves to a real file.
  3. The Karpathy guidelines file is still byte-for-byte verbatim (MD5 checksum).
  4. No reference file is empty.

Usage (run from anywhere):
    python3 validate_skill.py                 # assumes skill root is the parent of this script
    python3 validate_skill.py /path/to/atelier

Exit code 0 = all good. Exit code 1 = problems found (listed).
"""

import sys
import re
import hashlib
from pathlib import Path

# The known-good checksum of the original Karpathy guidelines.
# If the file is ever edited, this check fails on purpose — the governor must stay verbatim.
KARPATHY_MD5 = "568fe33228692e85543530ce376f695f"
KARPATHY_REL = "references/karpathy-guidelines.md"


def md5(path: Path) -> str:
    return hashlib.md5(path.read_bytes()).hexdigest()


def parse_frontmatter(text: str):
    """Return the frontmatter block (between the first two '---' lines) or None."""
    m = re.match(r"^---\s*\n(.*?)\n---\s*\n", text, re.DOTALL)
    return m.group(1) if m else None


def main():
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent

    problems = []
    checks_run = 0
    files_verified = 0

    # --- Check 1: SKILL.md + frontmatter ---
    checks_run += 1
    skill_md = root / "SKILL.md"
    if not skill_md.exists():
        problems.append(f"SKILL.md not found at {skill_md}")
        report(root, checks_run, files_verified, problems)
        return 1

    text = skill_md.read_text(encoding="utf-8")
    fm = parse_frontmatter(text)
    if fm is None:
        problems.append("SKILL.md has no valid frontmatter block (--- ... ---)")
    else:
        if "name:" not in fm:
            problems.append("SKILL.md frontmatter is missing a 'name:' field")
        if "description:" not in fm:
            problems.append("SKILL.md frontmatter is missing a 'description:' field")
    files_verified += 1

    # --- Check 2: every references/...md path in SKILL.md resolves ---
    checks_run += 1
    referenced = sorted(set(re.findall(r"`(references/[A-Za-z0-9._/-]+\.md)`", text)))
    for rel in referenced:
        target = root / rel
        if target.exists():
            files_verified += 1
        else:
            problems.append(f"Routing map points to a file that does not exist: {rel}")

    # --- Check 3: Karpathy verbatim ---
    checks_run += 1
    karpathy = root / KARPATHY_REL
    if not karpathy.exists():
        problems.append(f"Karpathy guidelines file is missing: {KARPATHY_REL}")
    else:
        actual = md5(karpathy)
        if actual == KARPATHY_MD5:
            files_verified += 1
        else:
            problems.append(
                f"Karpathy guidelines are NOT verbatim. Expected MD5 {KARPATHY_MD5}, "
                f"got {actual}. The governor must stay byte-for-byte intact."
            )

    # --- Check 4: no empty reference files ---
    checks_run += 1
    ref_dir = root / "references"
    if ref_dir.exists():
        for md_file in sorted(ref_dir.rglob("*.md")):
            if md_file.stat().st_size == 0:
                problems.append(f"Reference file is empty: {md_file.relative_to(root)}")

    return report(root, checks_run, files_verified, problems)


def report(root, checks_run, files_verified, problems):
    print(f"atelier integrity validation — {root}")
    print(f"  checks run: {checks_run}")
    print(f"  files verified: {files_verified}")
    if not problems:
        print("  result: COMPLETE — all checks passed, no problems found.")
        return 0
    print(f"  problems found: {len(problems)}")
    for i, p in enumerate(problems, 1):
        print(f"    {i}. {p}")
    print("  result: FAILED — fix the items above.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
