#!/usr/bin/env python3
"""
atelier — type scale generator
==============================
Builds a modular type scale (base size x ratio per step) with sensible line-heights, matching the
guidance in references/typography.md: body 15-16px minimum, line spacing 120-145% (tighter as size
grows), and a fluid clamp() suggestion for responsive sizing.

This is exact math, so it is run rather than estimated.

Named ratios (or pass any number with --ratio):
    minor-second 1.067 · major-second 1.125 · minor-third 1.2 · major-third 1.25
    perfect-fourth 1.333 · augmented-fourth 1.414 · perfect-fifth 1.5 · golden 1.618

Usage:
    python3 type_scale.py                                   # 16px base, major-third, 5 up / 2 down
    python3 type_scale.py --base 16 --ratio major-third
    python3 type_scale.py --base 18 --ratio 1.25 --up 6 --down 2
"""

import argparse

RATIOS = {
    "minor-second": 1.067,
    "major-second": 1.125,
    "minor-third": 1.2,
    "major-third": 1.25,
    "perfect-fourth": 1.333,
    "augmented-fourth": 1.414,
    "perfect-fifth": 1.5,
    "golden": 1.618,
}

# Step labels from smallest to largest, centered on body (step 0).
STEP_NAMES = {
    -2: "caption / fine print",
    -1: "small / secondary",
     0: "body (base)",
     1: "lead / h6",
     2: "h5",
     3: "h4",
     4: "h3",
     5: "h2",
     6: "h1",
     7: "display",
     8: "hero display",
}


def resolve_ratio(value: str) -> float:
    if value in RATIOS:
        return RATIOS[value]
    try:
        return float(value)
    except ValueError:
        raise SystemExit(f"unknown ratio: {value!r}. Use a name or a number (e.g. 1.25).")


def line_height(px: float, base: float) -> float:
    """Tighter line-height as size grows; body sits at the top of the documented 1.2-1.45 range."""
    r = px / base
    if r <= 1.0:
        return 1.45          # body and smaller
    if r <= 1.5:
        return 1.3
    if r <= 2.0:
        return 1.2
    return 1.1               # large display


def main():
    ap = argparse.ArgumentParser(description="Generate an atelier modular type scale.")
    ap.add_argument("--base", type=float, default=16.0, help="body size in px (default 16; floor 15)")
    ap.add_argument("--ratio", default="major-third", help="named ratio or a number (default major-third)")
    ap.add_argument("--up", type=int, default=5, help="steps above body (default 5)")
    ap.add_argument("--down", type=int, default=2, help="steps below body (default 2)")
    ap.add_argument("--root", type=float, default=16.0, help="root px for rem conversion (default 16)")
    args = ap.parse_args()

    if args.base < 15:
        print(f"note: body {args.base:g}px is below the 15px minimum in typography.md.\n")

    ratio = resolve_ratio(args.ratio)
    ratio_name = args.ratio if args.ratio in RATIOS else f"{ratio:g}"

    print(f"atelier type scale  (base {args.base:g}px, ratio {ratio_name} = {ratio:g}x)")
    print(f"  {'step':>5}  {'role':<22} {'size':>9} {'rem':>8} {'line-height':>12}")
    print(f"  {'-'*5}  {'-'*22} {'-'*9} {'-'*8} {'-'*12}")

    rows = []
    processed = 0
    for step in range(args.up, -args.down - 1, -1):
        px = args.base * (ratio ** step)
        px_r = round(px, 1)
        rem = round(px / args.root, 3)
        lh = line_height(px, args.base)
        role = STEP_NAMES.get(step, f"step {step:+d}")
        rows.append((step, px_r, rem, lh))
        processed += 1
        print(f"  {step:>+5}  {role:<22} {str(px_r)+'px':>9} {str(rem)+'rem':>8} {lh:>12.2f}")

    # CSS custom properties, body-centered naming
    print("\n  CSS custom properties:")
    props = []
    for step, px_r, rem, lh in rows:
        name = "base" if step == 0 else (f"up-{step}" if step > 0 else f"down-{abs(step)}")
        props.append(f"--font-{name}: {px_r}px;")
    print("    " + "  ".join(props))

    # Fluid clamp() suggestion for the largest heading: min one step down, max at size, fluid by vw
    top_step, top_px, _, _ = rows[0]
    min_px = round(args.base * (ratio ** (top_step - 1)), 1)
    print("\n  fluid example (largest heading), scaling between ~768px and 1366px viewports:")
    print(f"    font-size: clamp({min_px}px, {round(top_px/ (1366/100),2)}vw, {top_px}px);")

    print(f"\n  reminders from typography.md: cap text containers at ~65ch (45-90 char measure);")
    print(f"  kerning on; one space after punctuation; max ~3 heading levels in use.")
    print(f"\n  steps processed: {processed} — complete.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
