#!/usr/bin/env python3
"""
atelier — WCAG contrast checker
===============================
Computes the exact contrast ratio between two colors and reports WCAG pass/fail, so contrast
is never approximated by eye. Implements the standard in references/ux-accessibility.md.

Thresholds:
    AA  normal text   >= 4.5 : 1
    AA  large text    >= 3.0 : 1   (>=18.66px bold, or >=24px regular)
    AAA normal text   >= 7.0 : 1
    AAA large text    >= 4.5 : 1

Usage:
    python3 contrast_check.py "#1A1A1A" "#FFFFFF"
    python3 contrast_check.py 222 fff           # 3- or 6-digit hex, with or without '#'

You can pass any two colors (foreground and background order does not matter for the ratio).
"""

import sys


def parse_hex(s: str):
    s = s.strip().lstrip("#")
    if len(s) == 3:
        s = "".join(ch * 2 for ch in s)
    if len(s) != 6 or any(c not in "0123456789abcdefABCDEF" for c in s):
        raise ValueError(f"not a valid hex color: {s!r}")
    return tuple(int(s[i:i + 2], 16) for i in (0, 2, 4))


def relative_luminance(rgb):
    def chan(c):
        c = c / 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (chan(v) for v in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast_ratio(c1, c2):
    l1, l2 = relative_luminance(c1), relative_luminance(c2)
    lighter, darker = max(l1, l2), min(l1, l2)
    return (lighter + 0.05) / (darker + 0.05)


def verdict(ratio):
    return {
        "AA  normal (>=4.5)": ratio >= 4.5,
        "AA  large  (>=3.0)": ratio >= 3.0,
        "AAA normal (>=7.0)": ratio >= 7.0,
        "AAA large  (>=4.5)": ratio >= 4.5,
    }


def main():
    if len(sys.argv) != 3:
        print("usage: python3 contrast_check.py <color1> <color2>   e.g. \"#1A1A1A\" \"#FFFFFF\"")
        return 1
    try:
        c1 = parse_hex(sys.argv[1])
        c2 = parse_hex(sys.argv[2])
    except ValueError as e:
        print(f"error: {e}")
        return 1

    ratio = contrast_ratio(c1, c2)
    print(f"atelier contrast check")
    print(f"  color 1: #{'%02X%02X%02X' % c1}   color 2: #{'%02X%02X%02X' % c2}")
    print(f"  contrast ratio: {ratio:.2f} : 1\n")

    passes = verdict(ratio)
    checked = 0
    failed = []
    for label, ok in passes.items():
        checked += 1
        print(f"  [{'PASS' if ok else 'FAIL'}]  {label}")
        if not ok:
            failed.append(label.split('(')[0].strip())

    print(f"\n  levels checked: {checked}")
    if failed:
        print(f"  failed: {', '.join(failed)}")
        print("  result: see fails above. Body text needs AA normal (4.5) at minimum.")
    else:
        print("  result: COMPLETE — passes every WCAG level.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
